## Express - Customer Data Warehouse Processing

This project contains source code for Customer Data warehouse processing stages for Express. 
Following are the buildable sub-modules:
1. Customer Matching process (customer-matching)
2. Customer Enrichment process (customer-enrichment)
3. Dimension & Fact Load process (dim-fact-load)
4. Customer Deduplication (customer-dedup)
5. Common utilities and library functions (commons)
6. Unit test utilities (cdw-test-tools)
7. Assembly module that will create the deployment archive (cdw-assembly)

Apart from the build modules, the *scripts and properties* framework is present under **apps** directory.


#### Building the project
Run **mvn clean package** command build the project. The deployment zip file **cdw-processing.zip** will be generated under target folder at project root.
